from models.invoice import Invoice
from models.appointment import Appointment
from models.patient import Patient
from datetime import date

def get_invoices_for_user(user):
    invs = Invoice.load_all()
    if user.ruolo == 'amministratore':
        return invs
    physio_apps = {a.id for a in Appointment.get_appointments(physio_id=user.id)}
    return [inv for inv in invs if inv.appointment_id in physio_apps]

def create_invoice_for_appointment(app_id, importo):
    return Invoice.create_invoice(app_id, importo, date.today())

def mark_invoice_paid(inv_id):
    Invoice.mark_invoice_paid(inv_id)

def send_payment_reminder(inv_id):
    return Invoice.mark_payment_reminder_sent(inv_id)

def export_invoice_pdf(inv_id):
    inv = Invoice.get_invoice(inv_id)
    if not inv:
        return None
    try:
        from fpdf import FPDF
    except ImportError:
        return None
    app_list = Appointment.get_appointments(id=inv['appointment_id'])
    patient_name = ''
    if app_list:
        app = app_list[0]
        pat = Patient.get_by_id(app.patient_id)
        if pat:
            patient_name = f"{pat.nome} {pat.cognome}"
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font('Arial', 'B', 16)
    pdf.cell(0, 10, 'Fattura', ln=1, align='C')
    pdf.set_font('Arial', size=12)
    pdf.cell(0, 8, f"Numero: {inv_id}", ln=1)
    pdf.cell(0, 8, f"Data: {inv['data_emissione']}", ln=1)
    if patient_name:
        pdf.cell(0, 8, f"Paziente: {patient_name}", ln=1)
    pdf.cell(0, 8, f"Importo: €{inv['importo']}", ln=1)
    pdf.cell(0, 8, f"Stato: {inv['stato_pagamento']}", ln=1)
    out = f"Fattura_{inv_id}.pdf"
    pdf.output(out)
    return out
