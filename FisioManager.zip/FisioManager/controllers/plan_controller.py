from models.plan import TreatmentPlan

def create_treatment_plan(pid, descrizione):
    return TreatmentPlan.create_plan(pid, descrizione)

def complete_treatment_plan(plan_id):
    TreatmentPlan.mark_completed(plan_id)

def get_plans_for_patient(pid):
    return TreatmentPlan.get_plans_by_patient(pid)

def get_all_plans():
    return TreatmentPlan.load_all()
