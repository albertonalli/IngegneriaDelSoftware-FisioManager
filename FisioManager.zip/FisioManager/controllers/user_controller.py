from models.user import User

def get_all_users():
    return User.load_all()

def create_new_user(nome, email, password, ruolo):
    return User.create_user(nome, email, password, ruolo)
