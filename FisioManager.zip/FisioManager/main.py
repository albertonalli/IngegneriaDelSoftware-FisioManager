import tkinter as tk
from views.login_view import LoginWindow
from views.main_view import MainWindow

if __name__ == '__main__':
    root = tk.Tk()
    login_win = LoginWindow(root)
    root.mainloop()

    user = getattr(login_win, 'logged_in_user', None)
    if user:
        MainWindow(user)
