import tkinter as tk
from tkinter import ttk, messagebox
from controllers import plan_controller, patient_controller

class PlanWindow(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title("Piani di Trattamento")
        self.geometry("600x400")
        self.selected_plan_id = None
        list_frame = tk.Frame(self)
        list_frame.pack(side="left", fill="both", expand=True, padx=5, pady=5)
        tk.Label(list_frame, text="Elenco Piani:").pack(anchor="w")
        self.plan_listbox = tk.Listbox(list_frame)
        self.plan_listbox.config(bg="white", fg="black")
        self.plan_listbox.pack(side="left", fill="both", expand=True)
        scrollbar = tk.Scrollbar(list_frame, orient="vertical", command=self.plan_listbox.yview)
        scrollbar.pack(side="left", fill="y")
        self.plan_listbox.config(yscrollcommand=scrollbar.set)
        self.plan_listbox.bind("<<ListboxSelect>>", self.on_select)
        form_frame = tk.Frame(self)
        form_frame.pack(side="left", fill="y", padx=10, pady=5)
        tk.Label(form_frame, text="Paziente:").grid(row=0, column=0, sticky="e", pady=2)
        self.patient_var = tk.StringVar()
        patients = patient_controller.get_all_patients()
        patients.sort(key=lambda p: p.cognome)
        self.patient_options = [f"{p.id}: {p.nome} {p.cognome}" for p in patients]
        self.patient_combo = ttk.Combobox(form_frame, textvariable=self.patient_var, values=self.patient_options, state="readonly")
        self.patient_combo.grid(row=0, column=1, pady=2)
        tk.Label(form_frame, text="Descrizione:").grid(row=1, column=0, sticky="e", pady=2)
        self.desc_entry = tk.Entry(form_frame, bg="white", fg="black")
        self.desc_entry.grid(row=1, column=1, pady=2)
        self.desc_entry.configure(borderwidth=1, relief="solid")
        btn_frame = tk.Frame(form_frame)
        btn_frame.grid(row=2, column=0, columnspan=2, pady=5)
        add_btn = tk.Button(btn_frame, text="Aggiungi Piano", command=self.add_plan)
        add_btn.pack(side="left", padx=5)
        self.complete_btn = tk.Button(btn_frame, text="Completa Piano", command=self.complete_plan)
        self.complete_btn.pack(side="left", padx=5)
        self.complete_btn.config(state="disabled")
        self.refresh_list()
        style = ttk.Style(self)
        try:
            style.theme_use('default')
        except:
            pass
        style.configure('TCombobox', foreground='black', fieldbackground='white')

    def refresh_list(self):
        plans = plan_controller.get_all_plans()
        plans.sort(key=lambda pl: pl.id)
        self.plan_listbox.delete(0, tk.END)
        pats = patient_controller.get_all_patients()
        for pl in plans:
            pat_name = ""
            for p in pats:
                if p.id == pl.patient_id:
                    pat_name = f"{p.nome} {p.cognome}"; break
            status = "Completato" if getattr(pl, 'completato', False) else "Attivo"
            self.plan_listbox.insert(tk.END, f"{pl.id}: {pat_name} - {pl.descrizione} ({status})")
        self.selected_plan_id = None
        self.complete_btn.config(state="disabled")

    def on_select(self, event):
        selection = self.plan_listbox.curselection()
        if selection:
            index = selection[0]
            item_text = self.plan_listbox.get(index)
            try:
                plan_id = int(item_text.split(":")[0])
            except:
                plan_id = None
            if plan_id:
                plans = plan_controller.get_all_plans()
                pl = next((p for p in plans if p.id == plan_id), None)
                if pl:
                    self.selected_plan_id = plan_id
                    if getattr(pl, 'completato', False):
                        self.complete_btn.config(state="disabled")
                    else:
                        self.complete_btn.config(state="normal")

    def add_plan(self):
        if not self.patient_var.get():
            messagebox.showwarning("Campi obbligatori", "Seleziona un paziente.")
            return
        desc = self.desc_entry.get().strip()
        if not desc:
            messagebox.showwarning("Campi obbligatori", "Inserisci una descrizione per il piano.")
            return
        try:
            pid = int(self.patient_var.get().split(":")[0])
        except:
            pid = None
        if not pid:
            messagebox.showerror("Errore", "Selezione paziente non valida.")
            return
        plan = plan_controller.create_treatment_plan(pid, desc)
        if not plan:
            messagebox.showerror("Errore", "Impossibile creare il piano.")
        else:
            messagebox.showinfo("Successo", "Piano di trattamento aggiunto.")
            self.patient_combo.set('')
            self.desc_entry.delete(0, tk.END)
        self.refresh_list()

    def complete_plan(self):
        if not self.selected_plan_id:
            messagebox.showwarning("Selezione mancante", "Seleziona un piano da completare.")
            return
        plan_controller.complete_treatment_plan(self.selected_plan_id)
        messagebox.showinfo("Piano Completato", "Il piano di trattamento è stato segnato come completato.")
        self.refresh_list()