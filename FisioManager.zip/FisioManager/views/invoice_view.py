import tkinter as tk
from tkinter import ttk, messagebox

from controllers import invoice_controller, patient_controller
from models.appointment import Appointment
from models.invoice import Invoice

class InvoiceWindow(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title("Fatturazione")
        self.geometry("700x450")
        self.selected_inv_id = None

        list_frame = tk.Frame(self)
        list_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.inv_listbox = tk.Listbox(list_frame)
        self.inv_listbox.pack(fill=tk.BOTH, expand=True)
        self.inv_listbox.bind('<<ListboxSelect>>', self.on_invoice_select)

        btn_frame = tk.Frame(list_frame)
        btn_frame.pack(fill=tk.X, pady=(5,0))
        tk.Button(btn_frame, text="Segna come Pagata", command=self.pay_invoice).pack(side=tk.LEFT, padx=(0,5))
        tk.Button(btn_frame, text="Invia Promemoria", command=self.remind_invoice).pack(side=tk.LEFT)

        create_frame = tk.LabelFrame(self, text="Nuova Fattura")
        create_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=10, pady=10)

        tk.Label(create_frame, text="Appuntamento:").grid(row=0, column=0, sticky=tk.W)
        self.app_var = tk.StringVar()
        self.app_combo = ttk.Combobox(create_frame, textvariable=self.app_var, state="readonly")
        self.app_combo.grid(row=0, column=1, sticky=tk.W)

        tk.Label(create_frame, text="Importo (€):").grid(row=1, column=0, sticky=tk.W)
        self.amount_entry = tk.Entry(create_frame)
        self.amount_entry.grid(row=1, column=1, sticky=tk.W)

        btn_create = tk.Button(
            create_frame,
            text="Crea Fattura",
            command=self.add_invoice
        )
        btn_create.grid(row=2, column=0, columnspan=2, pady=(5,0))

        self.update_appointment_options()
        self.refresh_list()

    def update_appointment_options(self):
        apps = Appointment.load_all()
        completed = [a for a in apps if a.stato == 'completato']
        choices = [f"{a.id}: {a.data} {a.ora}" for a in completed]
        self.app_combo['values'] = choices
        if choices:
            self.app_combo.current(0)

    def add_invoice(self):
        sel = self.app_combo.get()
        if not sel:
            messagebox.showwarning("Selezione mancante", "Seleziona un appuntamento.")
            return
        app_id = int(sel.split(":")[0])
        try:
            amount = float(self.amount_entry.get())
        except ValueError:
            messagebox.showerror("Errore", "Importo non valido.")
            return
        inv = invoice_controller.create_invoice_for_appointment(app_id, amount)
        if inv:
            messagebox.showinfo("Fattura Creata", f"Fattura #{inv.id} creata con successo.")
            self.amount_entry.delete(0, tk.END)
            self.refresh_list()
        else:
            messagebox.showerror("Errore", "Impossibile creare la fattura.")

    def refresh_list(self):
        self.inv_listbox.delete(0, tk.END)
        for inv in Invoice.load_all():
            stato = "Pagata" if inv.stato_pagamento == 'pagata' else "Da pagare"
            nome_paziente = "Sconosciuto"
            apps = Appointment.get_appointments(id=inv.appointment_id)
            if apps:
                app = apps[0]
                pat = patient_controller.get_patient_by_id(app.patient_id)
                if pat:
                    nome_paziente = f"{pat.nome} {pat.cognome}"
            display_text = (
                f"{inv.id}: App {inv.appointment_id} — {nome_paziente} — "
                f"€{inv.importo:.2f} — {stato}"
            )
            self.inv_listbox.insert(tk.END, display_text)
        self.selected_inv_id = None
        self.update_appointment_options()

    def on_invoice_select(self, event):
        sel = self.inv_listbox.curselection()
        if sel:
            text = self.inv_listbox.get(sel)
            self.selected_inv_id = int(text.split(":")[0])

    def pay_invoice(self):
        if not self.selected_inv_id:
            messagebox.showwarning("Selezione mancante", "Seleziona una fattura da segnare come pagata.")
            return
        invoice_controller.mark_invoice_paid(self.selected_inv_id)
        messagebox.showinfo("Fattura Pagata", "La fattura è stata segnata come pagata.")
        self.refresh_list()

    def remind_invoice(self):
        if not self.selected_inv_id:
            messagebox.showwarning("Selezione mancante", "Seleziona una fattura.")
            return
        invoices = Invoice.load_all()
        inv = next((i for i in invoices if i.id == self.selected_inv_id), None)
        if inv and inv.stato_pagamento == 'pagata':
            messagebox.showinfo("Fattura già pagata", "La fattura è già stata pagata.")
            return
        invoice_controller.send_payment_reminder(self.selected_inv_id)
        messagebox.showinfo("Promemoria", "Promemoria di pagamento inviato.")
        self.refresh_list()
