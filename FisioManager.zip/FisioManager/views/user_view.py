import tkinter as tk
from tkinter import messagebox
from controllers import user_controller

class UserWindow(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title("Gestione Utenti")
        self.geometry("500x400")
        list_frame = tk.Frame(self)
        list_frame.pack(side="top", fill="both", expand=True, padx=5, pady=5)
        tk.Label(list_frame, text="Utenti registrati:").pack(anchor="w")
        self.user_listbox = tk.Listbox(list_frame)
        self.user_listbox.config(bg="white", fg="black")
        self.user_listbox.pack(side="left", fill="both", expand=True)
        scrollbar = tk.Scrollbar(list_frame, orient="vertical", command=self.user_listbox.yview)
        scrollbar.pack(side="left", fill="y")
        self.user_listbox.config(yscrollcommand=scrollbar.set)
        form_frame = tk.Frame(self)
        form_frame.pack(side="bottom", fill="x", padx=5, pady=5)
        tk.Label(form_frame, text="Nome:").grid(row=0, column=0, sticky="e", pady=2)
        self.nome_entry = tk.Entry(form_frame, bg="white", fg="black")
        self.nome_entry.grid(row=0, column=1, pady=2)
        tk.Label(form_frame, text="Email:").grid(row=1, column=0, sticky="e", pady=2)
        self.email_entry = tk.Entry(form_frame, bg="white", fg="black")
        self.email_entry.grid(row=1, column=1, pady=2)
        tk.Label(form_frame, text="Password:").grid(row=2, column=0, sticky="e", pady=2)
        self.pwd_entry = tk.Entry(form_frame, show="*", bg="white", fg="black")
        self.pwd_entry.grid(row=2, column=1, pady=2)
        tk.Label(form_frame, text="Ruolo:").grid(row=3, column=0, sticky="e", pady=2)
        self.ruolo_var = tk.StringVar(value="Fisioterapista")
        ruolo_options = ("Fisioterapista", "Admin")
        self.ruolo_menu = tk.OptionMenu(form_frame, self.ruolo_var, *ruolo_options)
        self.ruolo_menu.grid(row=3, column=1, pady=2, sticky="w")
        for entry in (self.nome_entry, self.email_entry, self.pwd_entry):
            entry.configure(borderwidth=1, relief="solid")
        add_btn = tk.Button(form_frame, text="Aggiungi Utente", command=self.add_user)
        add_btn.grid(row=4, column=0, columnspan=2, pady=5)
        self.refresh_list()

    def refresh_list(self):
        users = user_controller.get_all_users()
        users.sort(key=lambda u: u.id)
        self.user_listbox.delete(0, tk.END)
        for u in users:
            r = u.ruolo.lower()
            if r in ('Fisioterapista', 'fisioterapista'):
                role_name = "Fisioterapista"
            else:
                role_name = "Admin"
            self.user_listbox.insert(
                tk.END,
                f"{u.id}: {u.nome} ({u.email}) - {role_name}"
            )

    def add_user(self):
        nome = self.nome_entry.get().strip()
        email = self.email_entry.get().strip()
        pwd = self.pwd_entry.get().strip()
        ruolo = self.ruolo_var.get().strip()
        if not nome or not email or not pwd:
            messagebox.showwarning("Campi obbligatori", "Inserisci nome, email e password.")
            return
        user = user_controller.create_new_user(nome, email, pwd, ruolo)
        if not user:
            messagebox.showerror("Errore", "Impossibile creare utente. Email forse già utilizzata.")
        else:
            messagebox.showinfo("Successo", "Utente creato correttamente.")
            self.nome_entry.delete(0, tk.END)
            self.email_entry.delete(0, tk.END)
            self.pwd_entry.delete(0, tk.END)
            self.ruolo_var.set("physio")
        self.refresh_list()