import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from controllers import appointment_controller, patient_controller

class AppointmentWindow(tk.Toplevel):
    def __init__(self, master=None, user=None):
        super().__init__(master)
        self.title("Gestione Appuntamenti")
        self.geometry("700x500")
        self.user = user
        self.selected_app_id = None
        list_frame = tk.Frame(self)
        list_frame.pack(side="top", fill="both", expand=True, padx=5, pady=5)
        tk.Label(list_frame, text="Agenda Appuntamenti:").pack(anchor="w")
        self.app_listbox = tk.Listbox(list_frame)
        self.app_listbox.config(bg="white", fg="black")
        self.app_listbox.pack(side="left", fill="both", expand=True)
        scrollbar = tk.Scrollbar(list_frame, orient="vertical", command=self.app_listbox.yview)
        scrollbar.pack(side="left", fill="y")
        self.app_listbox.config(yscrollcommand=scrollbar.set)
        self.app_listbox.bind("<<ListboxSelect>>", self.on_select)
        self.app_listbox.bind("<Double-1>", self.open_note)
        control_frame = tk.Frame(self)
        control_frame.pack(side="bottom", fill="x", pady=5)
        action_frame = tk.Frame(control_frame)
        action_frame.pack(side="left", padx=5)
        cancel_btn = tk.Button(action_frame, text="Annulla", command=self.cancel_appointment)
        cancel_btn.pack(side="top", fill="x", pady=2)
        complete_btn = tk.Button(action_frame, text="Completa", command=self.complete_appointment)
        complete_btn.pack(side="top", fill="x", pady=2)
        remind_btn = tk.Button(action_frame, text="Invia promemoria", command=self.send_reminder)
        remind_btn.pack(side="top", fill="x", pady=2)
        details_btn = tk.Button(action_frame, text="Vedi Note", command=self.show_note)
        details_btn.pack(side="top", fill="x", pady=2)
        for btn in (cancel_btn, complete_btn, remind_btn, details_btn):
            btn.config(state="disabled")
        self.cancel_btn = cancel_btn
        self.complete_btn = complete_btn
        self.remind_btn = remind_btn
        self.details_btn = details_btn
        form_frame = tk.Frame(control_frame, relief="groove", borderwidth=2)
        form_frame.pack(side="left", padx=20, pady=5)
        tk.Label(form_frame, text="Nuovo Appuntamento").grid(row=0, column=0, columnspan=2, pady=2)
        tk.Label(form_frame, text="Paziente:").grid(row=1, column=0, sticky="e", pady=2)
        self.patient_var = tk.StringVar()
        patients = patient_controller.get_all_patients()
        patients.sort(key=lambda p: p.cognome)
        self.patient_options = [f"{p.id}: {p.nome} {p.cognome}" for p in patients]
        self.patient_combo = ttk.Combobox(form_frame, textvariable=self.patient_var, values=self.patient_options, state="readonly")
        self.patient_combo.grid(row=1, column=1, pady=2)
        tk.Label(form_frame, text="Data (YYYY-MM-DD):").grid(row=2, column=0, sticky="e", pady=2)
        self.data_entry = tk.Entry(form_frame, bg="white", fg="black")
        self.data_entry.grid(row=2, column=1, pady=2)
        tk.Label(form_frame, text="Ora (HH:MM):").grid(row=3, column=0, sticky="e", pady=2)
        self.ora_entry = tk.Entry(form_frame, bg="white", fg="black")
        self.ora_entry.grid(row=3, column=1, pady=2)
        tk.Label(form_frame, text="Descrizione:").grid(row=4, column=0, sticky="e", pady=2)
        self.tratt_entry = tk.Entry(form_frame, bg="white", fg="black")
        self.tratt_entry.grid(row=4, column=1, pady=2)
        for entry in (self.data_entry, self.ora_entry, self.tratt_entry):
            entry.configure(borderwidth=1, relief="solid")
        add_btn = tk.Button(form_frame, text="Aggiungi", command=self.add_appointment)
        add_btn.grid(row=5, column=0, columnspan=2, pady=5)
        style = ttk.Style(self)
        try:
            style.theme_use('default')
        except:
            pass
        style.configure('TCombobox', foreground='black', fieldbackground='white')
        self.refresh_list()

    def refresh_list(self):
        apps = appointment_controller.get_schedule_for_date(self.user, data=None)
        try:
            apps.sort(key=lambda a: (a.data, a.ora))
        except:
            apps.sort(key=lambda a: a.id)
        self.app_listbox.delete(0, tk.END)
        pats = {p.id: f"{p.nome} {p.cognome}" for p in patient_controller.get_all_patients()}
        for a in apps:
            pname = pats.get(a.patient_id, "N/D")
            status = a.stato.capitalize()
            rem_flag = " (Promemoria inviato)" if getattr(a, 'promemoria', False) else ""
            item_text = f"{a.id}: {a.data} {a.ora} - {pname} - {a.trattamento} [{status}]{rem_flag}"
            self.app_listbox.insert(tk.END, item_text)
        self.selected_app_id = None
        for btn in (self.cancel_btn, self.complete_btn, self.remind_btn, self.details_btn):
            btn.config(state="disabled")

    def on_select(self, event):
        selection = self.app_listbox.curselection()
        if selection:
            index = selection[0]
            item_text = self.app_listbox.get(index)
            try:
                aid = int(item_text.split(":")[0])
            except:
                aid = None
            if aid:
                self.selected_app_id = aid
                apps = appointment_controller.get_schedule_for_date(self.user, data=None)
                appt = next((a for a in apps if a.id == aid), None)
                if appt:
                    if appt.stato == 'annullato':
                        self.cancel_btn.config(state="disabled")
                        self.complete_btn.config(state="disabled")
                        self.remind_btn.config(state="disabled")
                    else:
                        self.cancel_btn.config(state="normal")
                        if appt.stato != 'completato':
                            self.complete_btn.config(state="normal")
                        else:
                            self.complete_btn.config(state="disabled")
                        if appt.stato == 'programmato':
                            self.remind_btn.config(state="normal")
                        else:
                            self.remind_btn.config(state="disabled")
                    if appt.note_cliniche:
                        self.details_btn.config(state="normal")
                    else:
                        self.details_btn.config(state="disabled")

    def add_appointment(self):
        if not self.patient_var.get():
            messagebox.showwarning("Campi obbligatori", "Seleziona un paziente.")
            return
        data = self.data_entry.get().strip()
        ora = self.ora_entry.get().strip()
        tratt = self.tratt_entry.get().strip()
        if not data or not ora or not tratt:
            messagebox.showwarning("Campi obbligatori", "Compila tutti i campi (data, ora, descrizione).")
            return
        if len(data) != 10 or data[4] != '-' or data[7] != '-':
            messagebox.showwarning("Formato data", "Usa formato YYYY-MM-DD per la data.")
            return
        if len(ora) not in (4, 5) or ':' not in ora:
            messagebox.showwarning("Formato ora", "Usa formato HH:MM per l'ora.")
            return
        try:
            pid = int(self.patient_var.get().split(":")[0])
        except:
            pid = None
        if not pid:
            messagebox.showerror("Errore", "Selezione paziente non valida.")
            return
        physio_id = getattr(self.user, 'id', None)
        if physio_id is None:
            physio_id = 0
        app = appointment_controller.create_new_appointment(pid, physio_id, data, ora, tratt)
        if not app:
            messagebox.showerror("Errore", "Impossibile creare l'appuntamento.")
        else:
            messagebox.showinfo("Successo", "Appuntamento aggiunto.")
            self.patient_combo.set('')
            self.data_entry.delete(0, tk.END)
            self.ora_entry.delete(0, tk.END)
            self.tratt_entry.delete(0, tk.END)
        self.refresh_list()

    def cancel_appointment(self):
        if not self.selected_app_id:
            messagebox.showwarning("Selezione mancante", "Seleziona un appuntamento da annullare.")
            return
        if not messagebox.askyesno("Conferma", "Sei sicuro di voler annullare l'appuntamento selezionato?"):
            return
        appointment_controller.cancel_appointment(self.selected_app_id)
        messagebox.showinfo("Appuntamento annullato", "L'appuntamento è stato annullato.")
        self.refresh_list()

    def complete_appointment(self):
        if not self.selected_app_id:
            messagebox.showwarning("Selezione mancante", "Seleziona un appuntamento da completare.")
            return
        note = simpledialog.askstring("Completa Appuntamento", "Inserisci note sull'esito (opzionale):", parent=self)
        if note is None:
            return
        appointment_controller.complete_appointment(self.selected_app_id, note)
        messagebox.showinfo("Appuntamento completato", "L'appuntamento è stato segnato come completato.")
        self.refresh_list()

    def send_reminder(self):
        if not self.selected_app_id:
            messagebox.showwarning("Selezione mancante", "Seleziona un appuntamento.")
            return
        appointment_controller.send_appointment_reminder(self.selected_app_id)
        messagebox.showinfo("Promemoria", "Promemoria inviato al paziente.")
        self.refresh_list()

    def open_note(self, event):
        if not self.selected_app_id:
            return
        apps = appointment_controller.get_schedule_for_date(self.user, data=None)
        appt = next((a for a in apps if a.id == self.selected_app_id), None)
        if appt and appt.note_cliniche:
            messagebox.showinfo("Note Appuntamento", f"Note:\n{appt.note_cliniche}")

    def show_note(self):
        if not self.selected_app_id:
            messagebox.showwarning("Selezione mancante", "Seleziona un appuntamento.")
            return
        apps = appointment_controller.get_schedule_for_date(self.user, data=None)
        appt = next((a for a in apps if a.id == self.selected_app_id), None)
        if appt and appt.note_cliniche:
            messagebox.showinfo("Note Appuntamento", f"Note:\n{appt.note_cliniche}")
        else:
            messagebox.showinfo("Note Appuntamento", "Nessuna nota disponibile.")