import tkinter as tk
from tkinter import messagebox, filedialog

from controllers import patient_controller
from models.appointment import Appointment
from models.invoice import Invoice

class PatientWindow(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title("Gestione Pazienti")
        self.geometry("600x400")
        self.selected_patient_id = None

        left_frame = tk.Frame(self)
        left_frame.pack(side="left", fill="both", expand=True, padx=5, pady=5)
        tk.Label(left_frame, text="Elenco Pazienti:").pack(anchor="w")
        search_frame = tk.Frame(left_frame)
        search_frame.pack(fill="x", pady=(0,5))
        self.search_var = tk.StringVar()
        tk.Entry(search_frame, textvariable=self.search_var).pack(side="left", fill="x", expand=True)
        tk.Button(search_frame, text="Cerca", command=self.search_patient).pack(side="left", padx=5)
        tk.Button(search_frame, text="Clear", command=self.clear_search).pack(side="left")
        self.no_results_label = tk.Label(left_frame, text="Nessun paziente trovato.", fg="red")
        self.patient_listbox = tk.Listbox(left_frame)
        self.patient_listbox.pack(side="left", fill="both", expand=True)
        scrollbar = tk.Scrollbar(left_frame, orient="vertical", command=self.patient_listbox.yview)
        scrollbar.pack(side="left", fill="y")
        self.patient_listbox.config(yscrollcommand=scrollbar.set)
        self.patient_listbox.bind("<<ListboxSelect>>", self.on_select)

        right_frame = tk.Frame(self)
        right_frame.pack(side="right", fill="y", padx=10, pady=5)
        labels = ["Nome", "Cognome", "Codice Fiscale", "Email", "Telefono", "Note"]
        self.entries = {}
        for idx, text in enumerate(labels):
            tk.Label(right_frame, text=f"{text}:").grid(row=idx, column=0, sticky="e", pady=2)
            entry = tk.Entry(right_frame)
            entry.grid(row=idx, column=1, pady=2)
            self.entries[text] = entry
        self.nome_entry = self.entries["Nome"]
        self.cognome_entry = self.entries["Cognome"]
        self.cf_entry = self.entries["Codice Fiscale"]
        self.email_entry = self.entries["Email"]
        self.tel_entry = self.entries["Telefono"]
        self.note_entry = self.entries["Note"]
        btn_frame = tk.Frame(right_frame)
        btn_frame.grid(row=6, column=0, columnspan=2, pady=10)
        tk.Button(btn_frame, text="Nuovo", command=lambda: self.clear_form(keep_search=True)).pack(side="left", padx=5)
        self.add_btn = tk.Button(btn_frame, text="Aggiungi", command=self.add_patient)
        self.add_btn.pack(side="left", padx=5)
        self.update_btn = tk.Button(btn_frame, text="Aggiorna", command=self.update_patient, state="disabled")
        self.update_btn.pack(side="left", padx=5)
        self.delete_btn = tk.Button(btn_frame, text="Elimina", command=self.delete_patient, state="disabled")
        self.delete_btn.pack(side="left", padx=5)
        tk.Button(btn_frame, text="Scarica Fascicolo", command=self.download_report).pack(side="left", padx=5)

        self.refresh_list()

    def refresh_list(self):
        self.no_results_label.pack_forget()
        patients = patient_controller.get_all_patients()
        patients.sort(key=lambda p: p.id)
        self.patient_listbox.delete(0, tk.END)
        for p in patients:
            self.patient_listbox.insert(tk.END, f"{p.id}: {p.nome} {p.cognome}")
        self.clear_form(keep_search=True)

    def search_patient(self):
        query = self.search_var.get().strip().lower()
        if not query:
            self.refresh_list()
            return
        patients = patient_controller.get_all_patients()
        filtered = [p for p in patients if query in p.nome.lower()
                                      or query in p.cognome.lower()
                                      or query in p.codice_fiscale.lower()]
        self.patient_listbox.delete(0, tk.END)
        if filtered:
            self.no_results_label.pack_forget()
            for p in filtered:
                self.patient_listbox.insert(tk.END, f"{p.id}: {p.nome} {p.cognome}")
        else:
            self.no_results_label.pack(anchor="w")

    def clear_search(self):
        self.refresh_list()

    def on_select(self, event):
        self.no_results_label.pack_forget()
        sel = self.patient_listbox.curselection()
        if not sel:
            return
        pid = int(self.patient_listbox.get(sel[0]).split(":")[0])
        pat = patient_controller.get_patient_by_id(pid)
        if not pat:
            return
        self.selected_patient_id = pid
        self.nome_entry.delete(0, tk.END); self.nome_entry.insert(0, pat.nome)
        self.cognome_entry.delete(0, tk.END); self.cognome_entry.insert(0, pat.cognome)
        self.cf_entry.delete(0, tk.END); self.cf_entry.insert(0, pat.codice_fiscale)
        self.email_entry.delete(0, tk.END); self.email_entry.insert(0, pat.email)
        self.tel_entry.delete(0, tk.END); self.tel_entry.insert(0, pat.telefono)
        self.note_entry.delete(0, tk.END); self.note_entry.insert(0, pat.note)
        self.add_btn.config(state="disabled")
        self.update_btn.config(state="normal")
        self.delete_btn.config(state="normal")

    def clear_form(self, keep_search=False):
        for e in (self.nome_entry, self.cognome_entry, self.cf_entry,
                  self.email_entry, self.tel_entry, self.note_entry):
            e.delete(0, tk.END)
        self.patient_listbox.selection_clear(0, tk.END)
        self.selected_patient_id = None
        self.update_btn.config(state="disabled")
        self.add_btn.config(state="normal")
        self.delete_btn.config(state="disabled")
        self.no_results_label.pack_forget()
        if not keep_search:
            self.search_var.set('')

    def add_patient(self):
        nome = self.nome_entry.get().strip()
        cognome = self.cognome_entry.get().strip()
        cf = self.cf_entry.get().strip()
        email = self.email_entry.get().strip()
        tel = self.tel_entry.get().strip()
        note = self.note_entry.get().strip()
        if not nome or not cognome or not cf:
            messagebox.showwarning("Campi obbligatori", "Nome, Cognome e Codice Fiscale sono obbligatori.")
            return
        if tel and not tel.isdigit():
            messagebox.showerror("Errore", "Il telefono deve contenere solo cifre.")
            return
        if email and ("@" not in email or "." not in email[email.index("@"):]):
            messagebox.showerror("Errore", "Email non valida.")
            return
        patient = patient_controller.add_new_patient(nome, cognome, cf, email, tel, note)
        if patient is None:
            messagebox.showerror("Errore", "Codice fiscale già presente.")
            return
        messagebox.showinfo("Successo", "Paziente aggiunto.")
        self.clear_form()
        self.refresh_list()

    def update_patient(self):
        if not self.selected_patient_id:
            messagebox.showwarning("Selezione mancante", "Seleziona un paziente.")
            return
        nome = self.nome_entry.get().strip()
        cognome = self.cognome_entry.get().strip()
        cf = self.cf_entry.get().strip()
        email = self.email_entry.get().strip()
        tel = self.tel_entry.get().strip()
        note = self.note_entry.get().strip()
        if not nome or not cognome or not cf:
            messagebox.showwarning("Campi obbligatori", "Nome, Cognome e CF obbligatori.")
            return
        if tel and not tel.isdigit():
            messagebox.showerror("Errore", "Telefono: solo cifre.")
            return
        if email and ("@" not in email or "." not in email[email.index("@"):]):
            messagebox.showerror("Errore", "Email non valida.")
            return
        success = patient_controller.update_patient_info(
            self.selected_patient_id,
            nome=nome, cognome=cognome, codice_fiscale=cf,
            email=email, telefono=tel, note=note
        )
        if not success:
            messagebox.showerror("Errore", "Aggiornamento fallito.")
        else:
            messagebox.showinfo("Successo", "Paziente aggiornato.")
        self.clear_form()
        self.refresh_list()

    def delete_patient(self):
        if not self.selected_patient_id:
            messagebox.showwarning("Selezione mancante", "Seleziona un paziente da eliminare.")
            return
        confirm = messagebox.askyesno("Conferma Eliminazione", "Sei sicuro di voler eliminare questo paziente?")
        if not confirm:
            return
        patient_controller.delete_patient(self.selected_patient_id)
        messagebox.showinfo("Eliminato", "Paziente eliminato con successo.")
        self.clear_form()
        self.refresh_list()

    def download_report(self):
        if not self.selected_patient_id:
            messagebox.showwarning("Selezione mancante", "Seleziona un paziente.")
            return
        apps = Appointment.load_all()
        invs = Invoice.load_all()
        completed = [a for a in apps if a.patient_id==self.selected_patient_id and a.stato=='completato']
        if not completed:
            messagebox.showinfo("Nessuna Seduta", "Non ci sono sedute completate.")
            return
        completed.sort(key=lambda a: (a.data, a.ora))
        filepath = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("File di testo","*.txt")], title="Salva Fascicolo Paziente")
        if not filepath:
            return
        pat = patient_controller.get_patient_by_id(self.selected_patient_id)
        lines = [f"Fascicolo Paziente: {pat.nome} {pat.cognome} (ID {pat.id})\n\n", "Storico Sedute:\n"]
        for a in completed:
            inv = next((i for i in invs if i.appointment_id==a.id), None)
            costo = f"€{inv.importo:.2f}" if inv and hasattr(inv, 'importo') else "N/D"
            lines.append(f"- {a.data} {a.ora} | {a.trattamento or '—'} | Costo: {costo}\n")
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.writelines(lines)
            messagebox.showinfo("Fascicolo Salvato", f"Report salvato in:\n{filepath}")
        except Exception as e:
            messagebox.showerror("Errore Salvataggio", f"Impossibile scrivere il file:\n{e}")
