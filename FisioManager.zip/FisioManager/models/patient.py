from models import storage

class Patient:
    file_name = 'patients.json'

    def __init__(self, id, owner_id, nome, cognome, codice_fiscale, email='', telefono='', note=''):
        self.id = id
        self.owner_id = owner_id
        self.nome = nome
        self.cognome = cognome
        self.codice_fiscale = codice_fiscale
        self.email = email
        self.telefono = telefono
        self.note = note

    def to_dict(self):
        return {
            "id": self.id,
            "owner_id": self.owner_id,
            "nome": self.nome,
            "cognome": self.cognome,
            "codice_fiscale": self.codice_fiscale,
            "email": self.email,
            "telefono": self.telefono,
            "note": self.note
        }

    @classmethod
    def load_all(cls):
        data = storage.load_data(cls.file_name)
        return [cls(**item) for item in data]

    @classmethod
    def get_all_for_owner(cls, owner_id):
        return [p for p in cls.load_all() if p.owner_id == owner_id]

    @classmethod
    def get_by_id(cls, pid, owner_id):
        for p in cls.load_all():
            if p.id == pid and p.owner_id == owner_id:
                return p
        return None

    @classmethod
    def create_patient(cls, owner_id, nome, cognome, codice_fiscale, email='', telefono='', note=''):
        patients = cls.load_all()
        new_id = max([p.id for p in patients], default=0) + 1
        pat = cls(new_id, owner_id, nome, cognome, codice_fiscale, email, telefono, note)
        patients.append(pat)
        cls.save_all(patients)
        return pat

    @classmethod
    def update_patient(cls, pid, owner_id, **kwargs):
        patients = cls.load_all()
        for p in patients:
            if p.id == pid and p.owner_id == owner_id:
                for k, v in kwargs.items():
                    if v is not None and hasattr(p, k):
                        setattr(p, k, v)
                cls.save_all(patients)
                return True
        return False

    @classmethod
    def delete_patient(cls, pid):
        patients = cls.load_all()
        new_list = [p for p in patients if p.id != pid]
        if len(new_list) == len(patients):
            return False
        cls.save_all(new_list)
        return True

    @classmethod
    def search_patients(cls, owner_id, keyword):
        keyword = keyword.lower()
        return [
            p for p in cls.get_all_for_owner(owner_id)
            if keyword in p.nome.lower() 
               or keyword in p.cognome.lower() 
               or keyword in p.codice_fiscale.lower()
        ]

    @classmethod
    def save_all(cls, patients_list):
        data = [p.to_dict() for p in patients_list]
        storage.save_data(cls.file_name, data)
